fx_version 'cerulean'
game 'gta5'

author 'Kealix'
description 'A.T.D.H. - Tactical Deployment Hub (Standalone ESX)'
version '1.0.0'

-- Zwingt den Server, oxmysql VOR diesem Skript zu starten (verhindert Fehler)
dependencies {
    'oxmysql'
}

-- Die Config wird für Server UND Client geladen
shared_scripts {
    'config.lua'
}

-- Server-Logik (Datenbank etc.)
server_scripts {
    'server.lua'
}

-- Client-Logik (Menü anzeigen, Spieler teleportieren)
client_scripts {
    'client.lua'
}

-- Das ist die Menü-Oberfläche
ui_page 'html/index.html'
files {
    'html/index.html'
}